#!/usr/bin/env python3
"""
WebSocket Relay for MATLAB-Cesium-Grafana Satellite Control (v7-Grafana)

Based on websocket_relay04.py (v6) with InfluxDB integration for Grafana.

Changes from v6:
- Added InfluxDB 2.x write support for Grafana time-series dashboards
- All telemetry data is stored in InfluxDB for historical analysis
- Cesium WebSocket functionality is fully preserved (backward compatible)
- InfluxDB connection is optional - relay works without it (graceful fallback)

Architecture:
  MATLAB → JSON file → [this relay] → WebSocket → Cesium  (unchanged)
                                     → InfluxDB  → Grafana (new)
"""

import asyncio
import json
import math
import os
import logging
import time
import websockets
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from functools import partial

# ============= InfluxDB (optional) =============
try:
    from influxdb_client import InfluxDBClient, Point, WritePrecision
    from influxdb_client.client.write_api import SYNCHRONOUS
    INFLUXDB_AVAILABLE = True
except ImportError:
    INFLUXDB_AVAILABLE = False

# ============= CONFIG =============
class Config:
    # File paths (unchanged)
    TELEMETRY_FILE = "telemetry_out.json"
    COMMAND_FILE = "command_in.json"

    # WebSocket server settings (unchanged)
    HOST = "localhost"
    PORT = 8765

    # Timeouts and intervals (unchanged)
    TELEMETRY_STALE_THRESHOLD = 5
    WARNING_INTERVAL = 10
    STATUS_INTERVAL = 60
    RECONNECT_DELAY = 3
    FILE_READ_DELAY = 0.05

    # ===== NEW: InfluxDB settings =====
    INFLUXDB_ENABLED = True                       # False이면 InfluxDB 쓰기 비활성화
    INFLUXDB_URL     = "http://localhost:8086"
    INFLUXDB_TOKEN   = "vleo-satellite-token"     # docker-compose에서 설정한 토큰
    INFLUXDB_ORG     = "vleo"
    INFLUXDB_BUCKET  = "satellite"

# ============= LOGGING SETUP =============
def setup_logging():
    """Configure logging with appropriate format and level"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    return logging.getLogger("WebSocketRelay")

# ============= INFLUXDB WRITER (NEW) =============
class InfluxDBWriter:
    """Handles writing telemetry data to InfluxDB for Grafana visualization.

    Measurement schema:
      - attitude      : Euler angles (cmd vs actual)
      - angular_rate  : angular velocities (cmd vs actual)
      - wheel         : reaction wheel speeds
      - orbit         : position, velocity, altitude
      - system        : control mode, pointing error, sim time
    """

    def __init__(self):
        self.logger = logging.getLogger("WebSocketRelay.InfluxDB")
        self.write_api = None
        self.client = None
        self.write_count = 0
        self.error_count = 0

        if not Config.INFLUXDB_ENABLED:
            self.logger.info("InfluxDB is DISABLED in config")
            return

        if not INFLUXDB_AVAILABLE:
            self.logger.warning(
                "influxdb-client package not installed. "
                "Run: pip install influxdb-client"
            )
            return

        try:
            self.client = InfluxDBClient(
                url=Config.INFLUXDB_URL,
                token=Config.INFLUXDB_TOKEN,
                org=Config.INFLUXDB_ORG
            )
            self.write_api = self.client.write_api(write_options=SYNCHRONOUS)

            # Connection test
            health = self.client.health()
            if health.status == "pass":
                self.logger.info(
                    f"InfluxDB connected: {Config.INFLUXDB_URL} "
                    f"(org={Config.INFLUXDB_ORG}, bucket={Config.INFLUXDB_BUCKET})"
                )
            else:
                self.logger.warning(f"InfluxDB health check: {health.status}")
        except Exception as e:
            self.logger.warning(f"InfluxDB connection failed: {e}")
            self.logger.warning("Continuing without InfluxDB (Cesium still works)")
            self.write_api = None

    @property
    def is_available(self):
        return self.write_api is not None

    def write_telemetry(self, data):
        """Convert telemetry dict to InfluxDB points and write."""
        if not self.is_available:
            return

        try:
            points = self._build_points(data)
            self.write_api.write(
                bucket=Config.INFLUXDB_BUCKET,
                record=points
            )
            self.write_count += 1

            if self.write_count % 100 == 0:
                self.logger.info(
                    f"InfluxDB: {self.write_count} writes "
                    f"({self.error_count} errors)"
                )
        except Exception as e:
            self.error_count += 1
            if self.error_count <= 5 or self.error_count % 50 == 0:
                self.logger.error(f"InfluxDB write error #{self.error_count}: {e}")

    def _build_points(self, data):
        """Build InfluxDB Point objects from telemetry data."""
        points = []
        tag = "vleo_sim"

        # --- 1) Attitude (Euler 321, deg) ---
        euler_act = data.get("euler321_actual_deg", [0, 0, 0])
        euler_cmd = data.get("euler321_cmd_deg", [0, 0, 0])
        points.append(
            Point("attitude")
            .tag("source", tag)
            .field("roll_actual_deg",  float(euler_act[0]))
            .field("pitch_actual_deg", float(euler_act[1]))
            .field("yaw_actual_deg",   float(euler_act[2]))
            .field("roll_cmd_deg",     float(euler_cmd[0]))
            .field("pitch_cmd_deg",    float(euler_cmd[1]))
            .field("yaw_cmd_deg",      float(euler_cmd[2]))
        )

        # --- 2) Angular Rate (deg/s) ---
        ang_vel = data.get("angularVelocity", [0, 0, 0])
        tgt_rates = data.get("targetRates", [0, 0, 0])
        points.append(
            Point("angular_rate")
            .tag("source", tag)
            .field("roll_rate_dps",  float(ang_vel[0]) * 180.0 / math.pi)
            .field("pitch_rate_dps", float(ang_vel[1]) * 180.0 / math.pi)
            .field("yaw_rate_dps",   float(ang_vel[2]) * 180.0 / math.pi)
            .field("roll_rate_cmd",  float(tgt_rates[0]))
            .field("pitch_rate_cmd", float(tgt_rates[1]))
            .field("yaw_rate_cmd",   float(tgt_rates[2]))
        )

        # --- 3) Reaction Wheel Speed (rpm) ---
        wheels = data.get("wheel_speeds_rpm", [0, 0, 0])
        points.append(
            Point("wheel")
            .tag("source", tag)
            .field("x_rpm", float(wheels[0]))
            .field("y_rpm", float(wheels[1]))
            .field("z_rpm", float(wheels[2]))
        )

        # --- 4) Orbit ---
        pos_eci  = data.get("position_eci",  [0, 0, 0])
        vel_eci  = data.get("velocity_eci",  [0, 0, 0])
        pos_ecef = data.get("position_ecef", [0, 0, 0])

        # Altitude from ECEF (meters → km, subtract Earth radius)
        r_ecef_km = math.sqrt(
            pos_ecef[0]**2 + pos_ecef[1]**2 + pos_ecef[2]**2
        ) / 1000.0
        altitude_km = r_ecef_km - 6378.137

        # Speed (m/s)
        speed_ms = math.sqrt(
            vel_eci[0]**2 + vel_eci[1]**2 + vel_eci[2]**2
        )

        points.append(
            Point("orbit")
            .tag("source", tag)
            .field("pos_eci_x", float(pos_eci[0]))
            .field("pos_eci_y", float(pos_eci[1]))
            .field("pos_eci_z", float(pos_eci[2]))
            .field("vel_eci_x", float(vel_eci[0]))
            .field("vel_eci_y", float(vel_eci[1]))
            .field("vel_eci_z", float(vel_eci[2]))
            .field("altitude_km", altitude_km)
            .field("speed_ms",    speed_ms)
        )

        # --- 5) System status ---
        p_sys = (
            Point("system")
            .tag("source", tag)
            .field("ctrl_mode",      int(data.get("ctrl_mode", -1)))
            .field("ctrl_mode_name", str(data.get("ctrl_mode_name", "")))
            .field("sim_time",       float(data.get("time", 0)))
        )

        if "pointing_error_deg" in data:
            p_sys.field("pointing_error_deg", float(data["pointing_error_deg"]))

        # Quaternion (for completeness)
        quat = data.get("quaternion", [0, 0, 0, 1])
        p_sys.field("quat_x", float(quat[0]))
        p_sys.field("quat_y", float(quat[1]))
        p_sys.field("quat_z", float(quat[2]))
        p_sys.field("quat_w", float(quat[3]))

        points.append(p_sys)

        return points

    def close(self):
        """Clean up InfluxDB resources."""
        if self.write_api:
            try:
                self.write_api.close()
            except Exception:
                pass
        if self.client:
            try:
                self.client.close()
            except Exception:
                pass
        self.logger.info(
            f"InfluxDB closed. Total writes: {self.write_count}, "
            f"errors: {self.error_count}"
        )

# ============= FILE HANDLING (unchanged from v6) =============
class TelemetryFileHandler(FileSystemEventHandler):
    """Handler for telemetry file change events"""

    def __init__(self, telemetry_manager, event_loop):
        self.telemetry_manager = telemetry_manager
        self.event_loop = event_loop
        self.logger = logging.getLogger("WebSocketRelay.FileHandler")

    def on_modified(self, event):
        """Handle file modification events"""
        if not event.src_path.endswith(Config.TELEMETRY_FILE):
            return
        self.event_loop.call_soon_threadsafe(
            lambda: asyncio.create_task(self.telemetry_manager.read_telemetry())
        )

# ============= TELEMETRY MANAGER (modified for InfluxDB) =============
class TelemetryManager:
    """Manages telemetry data reading and processing"""

    def __init__(self, broadcaster, influxdb_writer):
        self.broadcaster = broadcaster
        self.influxdb_writer = influxdb_writer    # <-- NEW
        self.last_telemetry = {"initialized": False}
        self.last_telemetry_time = 0
        self.logger = logging.getLogger("WebSocketRelay.TelemetryManager")

    async def read_telemetry(self):
        """Read and process telemetry from the file"""
        try:
            await asyncio.sleep(Config.FILE_READ_DELAY)

            with open(Config.TELEMETRY_FILE, 'r') as f:
                file_content = f.read().strip()

                if not file_content:
                    self.logger.warning("Telemetry file is empty")
                    return

                telemetry = json.loads(file_content)

                if self._is_telemetry_changed(self.last_telemetry, telemetry):
                    self.logger.info(
                        f"New telemetry: {self._get_telemetry_summary(telemetry)}"
                    )

                self.last_telemetry = telemetry
                self.last_telemetry_time = time.time()

                # Broadcast to Cesium clients (unchanged)
                await self.broadcaster.broadcast_telemetry(telemetry)

                # ===== NEW: Write to InfluxDB =====
                self.influxdb_writer.write_telemetry(telemetry)

        except json.JSONDecodeError as e:
            self.logger.error(f"JSON decode error in telemetry file: {e}")
        except FileNotFoundError:
            self.logger.error(
                f"Telemetry file not found: {Config.TELEMETRY_FILE}"
            )
        except PermissionError:
            self.logger.error(
                "Permission denied when accessing telemetry file"
            )
        except Exception as e:
            self.logger.error(
                f"Error reading telemetry file: {str(e)}", exc_info=True
            )

    def _is_telemetry_changed(self, old, new):
        if not old or not new:
            return True
        for key in ['position_ecef', 'quaternion', 'time', 'ctrl_mode']:
            if key in new and (key not in old or old[key] != new[key]):
                return True
        return False

    def _get_telemetry_summary(self, telemetry):
        summary = {}
        if 'time' in telemetry:
            summary['time'] = telemetry['time']
        if 'ctrl_mode' in telemetry:
            summary['mode'] = telemetry['ctrl_mode']
        if 'position_ecef' in telemetry:
            pos = telemetry['position_ecef']
            summary['pos'] = f"({pos[0]:.0f}, {pos[1]:.0f}, {pos[2]:.0f})"
        return summary

# ============= WEBSOCKET HANDLING (unchanged from v6) =============
class WebSocketServer:
    """Manages WebSocket connections and communication with clients"""

    def __init__(self):
        self.connected_clients = set()
        self.client_command_count = {}
        self.logger = logging.getLogger("WebSocketRelay.WebSocketServer")
        self.current_ctrl_mode = 4

    async def handle_websocket(self, websocket):
        self.connected_clients.add(websocket)
        client_id = id(websocket)

        remote_address = websocket.remote_address
        if isinstance(remote_address, tuple) and len(remote_address) >= 2:
            client_ip, client_port = remote_address[0], remote_address[1]
            client_info = f"{client_ip}:{client_port}"
        else:
            client_info = str(remote_address)

        self.client_command_count[client_id] = 0

        self.logger.info(
            f"Client connected: {client_info} (ID: {client_id})"
        )
        self.logger.info(
            f"Total connected clients: {len(self.connected_clients)}"
        )

        try:
            async for message in websocket:
                try:
                    data = json.loads(message)

                    self.client_command_count[client_id] += 1
                    count = self.client_command_count[client_id]

                    cmd_str = data.get("command", "")
                    ctrl_mode = data.get("ctrl_mode", -1)

                    if ctrl_mode >= 0 and ctrl_mode <= 5:
                        self.current_ctrl_mode = ctrl_mode
                        self.logger.info(
                            f"Control mode change requested: {ctrl_mode}"
                        )

                    self.logger.info(
                        f"Command #{count} from {client_id}: "
                        f"cmd='{cmd_str}', mode={self.current_ctrl_mode}"
                    )

                    output_data = {
                        "command": cmd_str,
                        "ctrl_mode": self.current_ctrl_mode,
                        "timestamp": time.time(),
                        "client_id": str(client_id)
                    }

                    if "target_quaternion" in data:
                        output_data["target_quaternion"] = data["target_quaternion"]

                    with open(Config.COMMAND_FILE, 'w') as f:
                        json.dump(output_data, f, indent=2)

                    self.logger.debug(f"Wrote command to file: {output_data}")

                except json.JSONDecodeError:
                    self.logger.warning(
                        f"Received invalid JSON from client {client_id}"
                    )
                except Exception as e:
                    self.logger.error(f"Error processing message: {str(e)}")

        except websockets.exceptions.ConnectionClosed:
            self.logger.info(f"Client {client_id} connection closed")
        finally:
            await self._remove_client(websocket, client_id)

    async def _remove_client(self, websocket, client_id):
        if websocket in self.connected_clients:
            self.connected_clients.remove(websocket)
        if client_id in self.client_command_count:
            del self.client_command_count[client_id]
        self.logger.info(
            f"Client {client_id} removed. "
            f"Remaining clients: {len(self.connected_clients)}"
        )

    async def broadcast_telemetry(self, telemetry):
        if not self.connected_clients:
            return

        message = json.dumps(telemetry)
        success_count = 0
        failed_clients = []

        for client in self.connected_clients.copy():
            try:
                await client.send(message)
                success_count += 1
            except Exception as e:
                client_id = id(client)
                self.logger.error(
                    f"Error sending to client {client_id}: {str(e)}"
                )
                failed_clients.append((client, client_id))

        for client, client_id in failed_clients:
            await self._remove_client(client, client_id)

        if self.connected_clients:
            self.logger.debug(
                f"Telemetry broadcast to "
                f"{success_count}/{len(self.connected_clients)} clients"
            )

    async def send_initial_telemetry(self, websocket, telemetry):
        if telemetry.get("initialized", False):
            try:
                await websocket.send(json.dumps(telemetry))
                client_id = id(websocket)
                self.logger.info(
                    f"Sent initial telemetry to client {client_id}"
                )
                return True
            except Exception as e:
                client_id = id(websocket)
                self.logger.error(
                    f"Error sending initial telemetry: {str(e)}"
                )
                return False
        return False

# ============= MONITORING (unchanged) =============
class HealthMonitor:
    def __init__(self, telemetry_manager, websocket_server, influxdb_writer):
        self.telemetry_manager = telemetry_manager
        self.websocket_server = websocket_server
        self.influxdb_writer = influxdb_writer   # <-- NEW
        self.last_warning = 0
        self.logger = logging.getLogger("WebSocketRelay.HealthMonitor")

    async def run(self):
        self.logger.info("Health check monitoring started")
        while True:
            await self._check_telemetry_status()
            await self._log_periodic_status()
            await asyncio.sleep(1)

    async def _check_telemetry_status(self):
        current_time = time.time()
        if self.telemetry_manager.last_telemetry_time > 0:
            telemetry_age = current_time - self.telemetry_manager.last_telemetry_time
            if telemetry_age > Config.TELEMETRY_STALE_THRESHOLD:
                if current_time - self.last_warning > Config.WARNING_INTERVAL:
                    self.logger.warning(
                        f"No telemetry updates for {telemetry_age:.1f}s. "
                        "Is MATLAB running?"
                    )
                    self.last_warning = current_time
            else:
                if current_time - self.last_warning > Config.STATUS_INTERVAL:
                    self.logger.info(
                        f"Telemetry OK (last: {telemetry_age:.1f}s ago)"
                    )
                    self.last_warning = current_time
        else:
            if current_time - self.last_warning > Config.WARNING_INTERVAL:
                self.logger.warning(
                    "No telemetry since startup. Waiting for MATLAB..."
                )
                self.last_warning = current_time

    async def _log_periodic_status(self):
        current_time = time.time()
        if int(current_time) % Config.STATUS_INTERVAL < 1:
            mode = self.websocket_server.current_ctrl_mode
            influx_status = (
                f"writes={self.influxdb_writer.write_count}"
                if self.influxdb_writer.is_available
                else "disabled"
            )
            self.logger.info(
                f"Status: {len(self.websocket_server.connected_clients)} "
                f"clients, mode={mode}, influxdb={influx_status}"
            )

# ============= FILE INITIALIZATION (unchanged) =============
async def initialize_files():
    logger = logging.getLogger("WebSocketRelay.Init")

    if not os.path.exists(Config.COMMAND_FILE):
        try:
            with open(Config.COMMAND_FILE, 'w') as f:
                json.dump(
                    {"command": "", "ctrl_mode": 4, "initialized": True},
                    f, indent=2
                )
            logger.info(f"Created initial {Config.COMMAND_FILE}")
        except Exception as e:
            logger.error(f"Failed to create {Config.COMMAND_FILE}: {str(e)}")
            raise

    if not os.path.exists(Config.TELEMETRY_FILE):
        try:
            with open(Config.TELEMETRY_FILE, 'w') as f:
                json.dump({"initialized": False}, f, indent=2)
            logger.info(f"Created initial {Config.TELEMETRY_FILE}")
        except Exception as e:
            logger.error(
                f"Failed to create {Config.TELEMETRY_FILE}: {str(e)}"
            )
            raise

    logger.info("File initialization complete")

# ============= MAIN APPLICATION =============
class WebSocketRelay:
    """Main application class that coordinates all components"""

    def __init__(self):
        self.logger = logging.getLogger("WebSocketRelay.Main")
        self.influxdb_writer = InfluxDBWriter()             # <-- NEW
        self.websocket_server = WebSocketServer()
        self.telemetry_manager = TelemetryManager(
            self.websocket_server,
            self.influxdb_writer                            # <-- NEW
        )
        self.health_monitor = HealthMonitor(
            self.telemetry_manager,
            self.websocket_server,
            self.influxdb_writer                            # <-- NEW
        )
        self.observer = None
        self.server = None
        self.event_loop = None

    async def start(self):
        self.event_loop = asyncio.get_running_loop()

        self.logger.info("=" * 60)
        self.logger.info(
            "WebSocket Relay v7 - Satellite Control + Grafana"
        )
        self.logger.info("=" * 60)
        self.logger.info(
            f"InfluxDB: "
            f"{'ENABLED' if self.influxdb_writer.is_available else 'DISABLED'}"
        )

        await initialize_files()

        if os.path.exists(Config.TELEMETRY_FILE):
            await self.telemetry_manager.read_telemetry()

        script_dir = os.path.dirname(os.path.abspath(__file__)) or '.'
        self.observer = Observer()

        try:
            event_handler = TelemetryFileHandler(
                self.telemetry_manager, self.event_loop
            )
            self.observer.schedule(
                event_handler, path=script_dir, recursive=False
            )
            self.observer.start()
            self.logger.info(
                f"Monitoring "
                f"{os.path.join(script_dir, Config.TELEMETRY_FILE)} "
                "for changes"
            )
        except Exception as e:
            self.logger.error(
                f"Failed to start file observer: {str(e)}", exc_info=True
            )
            raise

        try:
            self.server = await websockets.serve(
                self.websocket_server.handle_websocket,
                Config.HOST,
                Config.PORT
            )
            self.logger.info(
                f"WebSocket server: ws://{Config.HOST}:{Config.PORT}"
            )
        except OSError as e:
            self.logger.error(
                f"Failed to start WebSocket server: {str(e)}"
            )
            self.logger.error(
                f"Port {Config.PORT} may already be in use."
            )
            self.observer.stop()
            self.observer.join()
            return
        except Exception as e:
            self.logger.error(
                f"Failed to start WebSocket server: {str(e)}",
                exc_info=True
            )
            self.observer.stop()
            self.observer.join()
            return

        health_task = asyncio.create_task(self.health_monitor.run())

        try:
            self.logger.info("Server running. Press Ctrl+C to stop.")
            self.logger.info(
                "Modes: 0=NoCtrl, 1=RateDamp, 2=Inertial, "
                "3=Nadir, 4=Interactive, 5=MomBias"
            )
            if self.influxdb_writer.is_available:
                self.logger.info(
                    f"Grafana dashboard: http://localhost:3000"
                )
            await asyncio.Future()
        finally:
            self.logger.info("Shutting down...")
            health_task.cancel()
            self.server.close()
            await self.server.wait_closed()
            self.observer.stop()
            self.observer.join()
            self.influxdb_writer.close()                    # <-- NEW
            self.logger.info("Shutdown complete.")


# ============= ENTRY POINT =============
async def main():
    relay = WebSocketRelay()
    await relay.start()


if __name__ == "__main__":
    logger = setup_logging()

    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Received keyboard interrupt")
        logger.info("Shutting down WebSocket relay")
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}", exc_info=True)
        raise
